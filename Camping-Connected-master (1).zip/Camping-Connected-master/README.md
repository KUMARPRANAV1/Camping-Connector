# Camping-Connected
It is a web application where people can explore sites for camping and share their own 
experiences.
The skills used here are:
HTML,CSS,JAVASCRIPT,MONGODB,EXPRESS
